#
#  Calculates and outputs inter-annotator agreements.
#  Uses the module bratiaa for calculations.
#
#  Required bratiaa version:
#    bratiaa   0.1.3 with fixes
#  (  
#     the bratiaa v0.1.3 contains some bugs (it does not work on Windows).
#     For running this script, you need the fixed version of bratiaa v0.1.3,
#     which can be obtained from here:
#     https://github.com/kldtz/bratiaa/tree/6c06aeb37be6550c7c6d92ad022947e792eaf43
#     ( just download the source and overwrite your bratiaa installation )
#   )
#
#  Notes: 
#    1) we use instance-based agreement because it is more strict;
#
#       *) token-based agreement ignores mismatches of token 
#          starts and ends, e.g. 'Jaan Hussar' vs 'Jaan Hussar.'
#          is not considered as a mismatch;
#
#       *) token-based agreement cumulates more matches due to 
#          splitting text into tokens, e.g. matching single 
#          phrase 'Talurahhwa Kuulutajasse' contributes to 2 
#          token matches: 'Talurahhwa' and 'Kuulutajasse'.
#          If there is a large number of matching phrases (like 
#          in case of person full names), this will amplify the 
#          number of positive matches, and diminish the number
#          of negative ones;
#
#    2) this should be a micro-average agreement
#

import re
import os, os.path

import bratiaa as biaa
from bratiaa.agree import input_generator

from bratiaa_agreement_view import BratiaaAgreementView
from bratiaa_agreement_view import extended_iaa_report_str

project_dir = 'koosk6la_arvutamine_3'

assert os.path.exists(project_dir), '(!) Missing directory {!r}'.format(project_dir)

def token_func(text):
    token = re.compile('\w+|[^\w\s]+')
    #token = re.compile('\S+')
    for match in re.finditer(token, text):
        yield match.start(), match.end()

# instance-level agreement
f1_agreement = biaa.compute_f1_agreement(project_dir)
#f1_agreement = biaa.compute_f1_agreement(project_dir, token_func=token_func)

# agreement view
biaa_viewer = BratiaaAgreementView(project_dir, input_generator)
#biaa_viewer = BratiaaAgreementView(project_dir, input_generator, token_func=token_func)

# generate extended view raport
raport_str_list = extended_iaa_report_str(f1_agreement, biaa_viewer, precision=3)

# output raport to screen & file
fname = 'agreement_'+str( '_'.join(biaa_viewer._annotators) )+'.txt'
with open(fname, 'w', encoding='utf-8') as out_f:
    for str in raport_str_list:
        print(str)
        out_f.write(str+'\n')
print()
print('Agreements written to file --->', fname)
