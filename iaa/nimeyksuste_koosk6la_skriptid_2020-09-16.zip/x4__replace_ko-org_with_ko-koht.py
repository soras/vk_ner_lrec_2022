#
#  Fix: before calculating IAA agreements, 
#       replace "KO_org" --> "KO_koht"
#
#  Reason: "KO_org" was an experimental label; 
#          once we noted that it was very difficult
#          distinguish "KO_org" and "KO_koht", we 
#          decided to merge "KO_org" into "KO_koht"
#

import re
import os, os.path


project_dirs = ['koosk6la_arvutamine_1', 'koosk6la_arvutamine_2', 'koosk6la_arvutamine_3']

total_labels = 0
for project_dir in project_dirs:
    assert os.path.exists(project_dir), '(!) Missing directory {!r}'.format(project_dir)
    for subdir in os.listdir(project_dir):
        dpath = os.path.join(project_dir, subdir)
        if os.path.isdir(dpath):
            for fname in os.listdir(dpath):
                fpath = os.path.join(dpath, fname)
                if fname.endswith('.ann'):
                    ko_org_labels = 0
                    with open(fpath, 'r', encoding='utf-8') as in_f:
                        lines = []
                        new_lines = []
                        for line in in_f:
                            lines.append( line )
                            fixed_line = line
                            if re.search(r'\tKO_org ', line, re.I):
                                ko_org_labels += 1
                                fixed_line = line.replace('KO_org', 'KO_koht')
                                assert fixed_line.count('KO_org') == 0
                            new_lines.append( fixed_line )
                    if ko_org_labels > 0:
                        total_labels += ko_org_labels
                        print(f'(!) {ko_org_labels} KO_org labels in file: {fname!r} in {subdir!r} of {project_dir}. Fixing the file.')
                        assert len(lines) == len(new_lines)
                        with open(fpath, 'w', encoding='utf-8') as out_f:
                            for n_line in new_lines:
                                out_f.write( n_line )
print()
print( 'Replaced labels:', total_labels )