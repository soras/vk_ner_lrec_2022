# Nimeüksuste märgenduse kooskõla hindamine

Skriptid märgenduste kooskõla analüüsiks:

* `x4__replace_ko-org_with_ko-koht.py`
	* parandab enne kooskõla arvutusi märgendust: teisendab märgendid "KO_org" märgenditeks "KO_koht". Põhjus: "KO_org" oli eksperimentaalne märgend; märgendamise käigus selgus, et "KO_org" ja "KO_koht" eristamine on keeruline, seetõttu otsustasime need üheks märgendiks kokku võtta. 

* `x4_find_iaa_margendaja1_vs_margendaja2.py`
* `x4_find_iaa_margendaja1_vs_yhisloome.py`
* `x4_find_iaa_margendaja2_vs_yhisloome.py`
	* leiab [bratiaa](https://github.com/kldtz/bratiaa) abil märgendajatevahelise kooskõla: väljastab iga dokumendi puhul lahkarvamused ning kooskõla näitajad; kõige lõpus väljastab kooskõlad nimeüksuse liikide kaupa ning üldise kooskõla. Kooskõla arvutamine toimub esimesel 250 protokollil (`vallakohus_esimene`). 
	* NB! Skriptide käimasaamiseks tuleb installida [tabulate](https://pypi.org/project/tabulate/) ja [bratiaa v0.1.3](https://pypi.org/project/bratiaa/0.1.3) ning lisada bratiaa-le parandused, mis on saadaval [siin](https://github.com/kldtz/bratiaa/tree/6c06aeb37be6550c7c6d92ad022947e792eaf43). 

Detailsem info skriptide päises; sisendargumendid skripti algusosas. 
   